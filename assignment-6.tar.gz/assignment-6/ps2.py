###### this is the second .py file ###########
#!/usr/bin/python
print 'Welcome to the Game'              #printing welcome
player = input ("press 1 for player_1 and 2 for the player_2")  # inituialising the players
tic = [[0 for x in range(3)] for y in range(3)] 
print "p1 will use odd numbers"                    # printing the players
print " p2 will take even numbers for playing"     #printing the player2
chance= input('enter the place and value')

####### write your code here ##########
